#!/bin/bash

#psql -h 127.0.0.1 -U <user> -d <database> -c "<SQL Command>"

# Set DB variables
HOST="localhost"
PORT="5432"
DB="adventureworks"   #"NorthwindDB"
USER="postgres"
#PSQL="/Library/PostgreSQL/16/bin"  # dynamically find the path
# Export password to avoid prompt (not recommended for production)
export PGPASSWORD=''

PSQL=$(which psql)
$PSQL -h $HOST -U $USER -d $DB -c "SELECT version();"


# Connect and create table (DDL)
psql -h $HOST -p $PORT -U $USER -d $DB -c "

CREATE TABLE IF NOT EXISTS employees3 (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50),
    department VARCHAR(50),
    salary INT
);"

# Insert sample data (DML)
psql -h $HOST -p $PORT -U $USER -d $DB -c "
INSERT INTO employees3 (name, department, salary)
VALUES
('Dimple', 'Engineering', 80000),
('Jonny', 'Sales', 60000),
('Voilett', 'HR', 50000);"

# Fetch records
psql -h $HOST -p $PORT -U $USER -d $DB -c "SELECT * FROM employees3;"
