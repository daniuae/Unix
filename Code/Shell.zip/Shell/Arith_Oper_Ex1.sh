#!/bin/bash
a=20
b=4

echo "Sum: $((a + b))"
echo "Difference: $((a - b))"
echo "Product: $((a * b))"
echo "Quotient: $((a / b))"
echo "Modulus: $((a % b))"
