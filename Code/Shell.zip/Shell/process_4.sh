#!/bin/bash
# Function creates a subprocess
function my_function {
    local local_var="Sneha"    # local to function
    global_var="Sangeetha"     # available in script
    export exported_var="Kapil"  # available to subprocess
}

my_function

echo "Script sees: local_var=$local_var, global_var=$global_var, exported_var=$exported_var"

bash -c 'echo "Subprocess sees: local_var=$local_var, global_var=$global_var, exported_var=$exported_var"'
