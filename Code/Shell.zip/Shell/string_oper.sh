#str="data"
#
#if [ -z "$str" ]; then
#  echo "String is empty"
#elif [ -n "$str" ]; then
#  echo "String is not empty"
#fi

str="data"

if [ -z "$str" ]; then
  echo "String is empty"
elif [ -n "$str" ]; then
  echo "String is not empty"
fi