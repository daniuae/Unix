my_array=(apple banana mango)
#echo ${my_array[0]}  # apple
for item in "${my_array[@]}"
do
    echo $item
done
