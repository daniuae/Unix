#!/bin/bash
a=10
b=5

sum=$(expr $a + $b)
echo "Sum: $sum"

diff=$(expr $a - $b)
echo "Difference: $diff"

prod=$(expr $a \* $b)
echo "Product: $prod"

quot=$(expr $a / $b)
echo "Quotient: $quot"

mod=$(expr $a % $b)
echo "Modulus: $mod"
