#!/bin/bash
city="Chennai" # Local variable
export state="TamilNadu" # Environment variable
echo "City: $city"
echo "State: $state"