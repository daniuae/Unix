#!/bin/bash

file="file1.txt"
size=$(stat -f%z "$file")

echo "File size of $file is $size bytes"