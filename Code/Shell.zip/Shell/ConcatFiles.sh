cat file1.txt file2.txt > merged.txt
