#!/bin/bash
# Local variable (not exported)
city="Chennai"

# Exported variable
state="Tamil Nadu"
export state

echo "Parent shell -> city: $city, state: $state"

bash -c 'echo "Child shell -> city: $city, state: $state"'
