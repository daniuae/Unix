read -p "Enter choice (yes/no): " input

case "$input" in
  [Yy][Ee][Ss]) echo "You said yes";;
  [Nn][Oo]) echo "You said no";;
  *) echo "Invalid input";;
esac
