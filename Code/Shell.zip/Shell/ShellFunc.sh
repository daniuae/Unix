hello() { echo "Hello, $1"; }
hello World
