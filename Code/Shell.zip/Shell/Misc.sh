#!/bin/bash
#Example 1
#name_value="Dani"
#echo "Hello, $name_value"
#
#echo "Enter you name"
#read name
#echo "Welcome, $name"


# Examples  2
#a=10
#b=5
#sum=$((a + b))
#echo "Sum is $sum"


#Example 3

current_date=$(date)
echo "Today is $current_date"

