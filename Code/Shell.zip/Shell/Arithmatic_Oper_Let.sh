#!/bin/bash
a=15
b=3

let sum=a+b
let diff=a-b
let prod=a*b
let quot=a/b
let mod=a%b

echo "Sum: $sum"
echo "Difference: $diff"
echo "Product: $prod"
echo "Quotient: $quot"
echo "Modulus: $mod"
