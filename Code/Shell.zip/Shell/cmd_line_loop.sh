#!/bin/bash

echo "All Arguments:"
for arg in "$@"
do
  echo "$arg"
done
