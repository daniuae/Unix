#!/bin/bash

arr=(a b c)
for item in "${arr[@]}"

do
  echo $item
done