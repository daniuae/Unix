#!/bin/bash
checkIfFileExists() {
    #Check if file exists
    if ! [ -e $1 ]; then
        error " does not exists";
    fi

    #Check if file permissions allow reading
    if ! [ -r $1 ]; then
        error "does not allow reading, please set the file permissions";
    fi
}

checkIfFileExists "'file'";