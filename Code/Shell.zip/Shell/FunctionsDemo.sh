#!/bin/bash
greet() {
    echo "Hello, $1"
}
greet 'Anna'



add_numbers() {
    result=$(( $1 + $2 ))
    echo $result
}

sum=$(add_numbers 3 5)
echo "Sum: $sum"


check_disk_space() {
    echo "Checking disk usage..."
    df -h
}

check_disk_space


log_info() {
    echo "[INFO] $(date '+%F %T') - $1"
}

log_info "Script started"
log_info "Backup completed"
