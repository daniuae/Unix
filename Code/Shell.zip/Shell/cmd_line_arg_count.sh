#!/bin/bash

if [ "$#" -ne 2 ]; then
  echo "Usage: $0 <source> <destination>"
  exit 1
fi

echo "Copying from $1 to $2"
cp "$1" "$2"
