#!/bin/bash

servers=("192.168.1.10" "192.168.1.11" "localhost")
:'
comments here
'
for server in "${servers[@]}"
do
    ping -c 1 $server &> /dev/null
    if [ $? -eq 0 ]; then
        echo "$server is reachable."
    else
        echo "$server is not reachable."
    fi
done
