#!/bin/bash
echo "Hello, $1!"
echo "Your age is $2!"
echo "You are from $3!"
echo "You passed $# arguments."
echo "All arguments: $@"